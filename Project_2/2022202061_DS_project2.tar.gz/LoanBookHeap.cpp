#include "LoanBookHeap.h"
#include <stack>

//heap insert
void LoanBookHeap::heapifyUp(LoanBookHeapNode* pN) {
    LoanBookHeapNode* curNode = pN;
    LoanBookHeapNode* parent = pN->getParent();

    if (parent == NULL)//curNode is first and only node
        return;

    while (parent != NULL) {
        if (parent->getBookData()->getName() > curNode->getBookData()->getName()) {//compare with parent node
            LoanBookData* temp = parent->getBookData();//swap
            parent->setBookData(curNode->getBookData());
            curNode->setBookData(temp);

            curNode = parent;
            parent = parent->getParent();
        }
        else
            break;
    }
}

//heap delete
//pN is neew root that need to be arrange
void LoanBookHeap::heapifyDown(LoanBookHeapNode* pN) {
    if (pN == NULL)//it was last delete
        return;

    LoanBookHeapNode* curNode = pN;
    LoanBookHeapNode* Lchild = pN->getLeftChild();
    LoanBookHeapNode* Rchild = pN->getRightChild();
    if (Lchild == NULL)//pN is last node that exist
        return;

    while (Lchild != NULL || Rchild != NULL) {
        if (Lchild != NULL && Rchild != NULL) {//two childnode
            if (Lchild->getBookData()->getName() < Rchild->getBookData()->getName()) {
                if (Lchild->getBookData()->getName() < curNode->getBookData()->getName()) {
                    //swap with left
                    LoanBookData* temp = Lchild->getBookData();
                    Lchild->setBookData(curNode->getBookData());
                    curNode->setBookData(temp);

                    curNode = Lchild;
                    Lchild = curNode->getLeftChild();
                    Rchild = curNode->getRightChild();
                }
                else
                    break;
            }
            else {
                if (Rchild->getBookData()->getName() < curNode->getBookData()->getName()) {
                    //swap with right
                    LoanBookData* temp = Rchild->getBookData();
                    Rchild->setBookData(curNode->getBookData());
                    curNode->setBookData(temp);

                    curNode = Rchild;
                    Lchild = curNode->getLeftChild();
                    Lchild = curNode->getLeftChild();
                    Rchild = curNode->getRightChild();
                }
                else
                    break;
            }
        }
        else if (Lchild != NULL) {
            if (Lchild->getBookData()->getName() < curNode->getBookData()->getName()) {
                LoanBookData* temp = Lchild->getBookData();//swap with left
                Lchild->setBookData(curNode->getBookData());
                curNode->setBookData(temp);
                break;
            }
            else
                break;
        }
        else {//Rchild!=NULL
            if (Rchild->getBookData()->getName() < curNode->getBookData()->getName()) {
                LoanBookData* temp = Rchild->getBookData();//swap with right
                Rchild->setBookData(curNode->getBookData());
                curNode->setBookData(temp);
                break;
            }
            else
                break;
        }
    }

}

bool LoanBookHeap::Insert(LoanBookData* data) {
    size++;
    int num = size;
    stack<int> s;
    int a = 0;
    while (num != 0) {
        a = num % 2;
        s.push(a);
        num /= 2;
    }

    LoanBookHeapNode* parent = getRoot();
    LoanBookHeapNode* prev = NULL;
    s.pop();
    while (s.empty() != true && parent != NULL) {
        a = s.top();
        s.pop();
        if (a == 0) {
            prev = parent;
            parent = parent->getLeftChild();
        }
        else {
            prev = parent;
            parent = parent->getRightChild();
        }
    }//find place to insert

    parent = prev;
    if (parent == NULL) {//first insert
        LoanBookHeapNode* newNode = new LoanBookHeapNode;
        newNode->setBookData(data);
        root = newNode;
    }
    else if (parent->getLeftChild() == NULL) {//left insert
        LoanBookHeapNode* newNode = new LoanBookHeapNode;
        newNode->setBookData(data);
        parent->setLeftChild(newNode);
        newNode->setParent(parent);
        heapifyUp(newNode);
    }
    else {//right insert
        LoanBookHeapNode* newNode = new LoanBookHeapNode;
        newNode->setBookData(data);
        parent->setRightChild(newNode);
        newNode->setParent(parent);
        heapifyUp(newNode);
    }

    return true;
}