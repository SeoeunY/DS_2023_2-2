#include "SelectionTree.h"
#include <stack>
#include <queue>
#include <map>

bool SelectionTree::Insert(LoanBookData* newData) {
	int code = newData->getCode();
	//find appropriate place and insert
	LoanBookData* a = NULL;
	LoanBookData* b = NULL;

	if (code != 0) {
		code /= 100;
	}

	if (arr[code]->getHeap()->getSize() > 0) {
		a = arr[code]->getHeap()->getRoot()->getBookData();
	}
	
	arr[code]->getHeap()->Insert(newData);//insert
	arr[code]->setBookData(arr[code]->getHeap()->getRoot()->getBookData());//update selection tree node book data
	b = arr[code]->getHeap()->getRoot()->getBookData();

	if (a == b)//root didn't change
		return true;

	arr[code]->setBookData(arr[code]->getHeap()->getRoot()->getBookData());
	//selection tree rearrange
	SelectionTreeNode* curNode = arr[code];
	SelectionTreeNode* parent = arr[code]->getParent();
	SelectionTreeNode* sibling;

	while (parent != NULL) {
		if (parent->getLeftChild() == curNode)
			sibling = parent->getRightChild();
		else
			sibling = parent->getLeftChild();
		//find sibling to have a tournament

		string curName = curNode->getBookData()->getName();
		if (sibling->getBookData() == NULL) {//unearned win
			parent->setBookData(curNode->getBookData());
			curNode = parent;
			parent = parent->getParent();
			continue;
		}

		string sibName = sibling->getBookData()->getName();
		if (curName < sibName) {//tournament
			parent->setBookData(curNode->getBookData());
		}
		else {//sibling win
			parent->setBookData(sibling->getBookData());
		}
		curNode = parent;
		parent = parent->getParent();
	}

	return true;
}

bool SelectionTree::Delete() {
	if (root->getBookData() == NULL)//selection tree null
		return false;

	SelectionTreeNode* curNode = root;
	while (curNode->getHeap() == NULL) {//search heap to delete
		if (curNode->getLeftChild()->getBookData() == curNode->getBookData()) {
			curNode->setBookData(NULL);
			curNode = curNode->getLeftChild();
		}
		else {
			curNode->setBookData(NULL);
			curNode = curNode->getRightChild();
		}
	}
	//curNode=selection tree node that contain heap to delete

	curNode->setBookData(NULL);
	int size = curNode->getHeap()->getSize();
	
	LoanBookHeapNode* cur = curNode->getHeap()->getRoot();
	LoanBookHeapNode* prev = NULL;

	if (size == 1) {
		LoanBookHeapNode* delheap = curNode->getHeap()->getRoot();
		delete delheap;
		curNode->getHeap()->setRoot(NULL);
		//rearrange selection tree with NULL
		//cur==null
	}
	else {
		stack<int> s;
		int a = 0;
		while (size != 0) {
			a = size % 2;
			s.push(a);
			size /= 2;
		}

		s.pop();
		while (s.empty() != true && cur != NULL) {
			a = s.top();
			s.pop();
			if (a == 0) {
				prev = cur;
				cur = cur->getLeftChild();
			}
			else {
				prev = cur;
				cur = cur->getRightChild();
			}
		}//find node that need to be new root (last level, most right node)

		LoanBookHeapNode* rooot = curNode->getHeap()->getRoot();//new root
		delete rooot->getBookData();
		rooot->setBookData(cur->getBookData());

		if (prev->getLeftChild() == cur)
			prev->setLeftChild(NULL);
		else
			prev->setRightChild(NULL);

		curNode->getHeap()->heapifyDown(curNode->getHeap()->getRoot());//rearrange heap
		curNode->setBookData(curNode->getHeap()->getRoot()->getBookData());
		cur->setBookData(NULL);
		delete cur;
	}

	curNode->getHeap()->reduceSize();

	//rearrange selection tree
	//SelectionTreeNode* curNode = arr[code];
	//curNode=selection tree node that contain heap to delete
	SelectionTreeNode* parent=curNode->getParent();
	SelectionTreeNode* sibling;

	while (parent != NULL) {
		if (parent->getLeftChild() == curNode)
			sibling = parent->getRightChild();
		else
			sibling = parent->getLeftChild();
		//find sibling

		if (curNode->getBookData() == NULL) {//sibling win (unearned win)
			parent->setBookData(sibling->getBookData());
			curNode = parent;
			parent = parent->getParent();
			continue;
		}

		string curName = curNode->getBookData()->getName();
		if (sibling->getBookData() == NULL) {//curNode unearned win
			parent->setBookData(curNode->getBookData());
			curNode = parent;
			parent = parent->getParent();
			continue;
		}

		string sibName = sibling->getBookData()->getName();
		if (curName < sibName) {//tournament
			parent->setBookData(curNode->getBookData());
		}
		else {//sibling win
			parent->setBookData(sibling->getBookData());
		}
		curNode = parent;
		parent = parent->getParent();
	}

	return true;
}

bool SelectionTree::printBookData(int bookCode) {
	bool suc = false;
	int check[8] = { 0,100,200,300,400,500,600,700 };
	for (int i = 0; i < 8; i++) {//check for correct bookcode
		if (bookCode == check[i])
			suc = true;
	}
	
	if (suc == false)
		return false;
	
	LoanBookHeap* print;
	if (bookCode == 0) {
		//print 000
		print = arr[0]->getHeap();
	}
	else {
		bookCode /= 100;
		//print bookCode
		print = arr[bookCode]->getHeap();
	}


	map<string, LoanBookData*>m;
	queue<LoanBookHeapNode*>q;

	LoanBookHeapNode* curNode = print->getRoot();

	if (curNode == NULL)
		return false;

	q.push(curNode);

	while (q.size() != 0) {
		LoanBookHeapNode* now = q.front();
		q.pop();
		if (now->getLeftChild() != NULL)
			q.push(now->getLeftChild());
		if (now->getRightChild() != NULL)
			q.push(now->getRightChild());
		m.insert({ now->getBookData()->getName(),now->getBookData() });
	}//insert all heapnode to map

	//automatically arrange with ascending name order
	*fout << "========PRINT_ST========" << endl;
	for (auto iter = m.begin(); iter != m.end(); iter++) {
		*fout << iter->first << "/" << iter->second->getCode() << "/" << iter->second->getAuthor() << "/" << iter->second->getYear() << "/" << iter->second->getLoanCount() << endl;
	}
	*fout<<"========================="<<endl<<endl;

	return true;
}