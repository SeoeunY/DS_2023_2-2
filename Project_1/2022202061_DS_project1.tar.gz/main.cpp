#include "Manager.h"//manager header file

int main()
{
	Manager manager;//create object
	manager.run("command.txt");//call run function

	return 0;//program end
}
