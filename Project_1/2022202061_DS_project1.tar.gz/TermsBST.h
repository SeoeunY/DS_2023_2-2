#pragma once
#include "TermsBSTNode.h"

class TermsBST
{
private:
	TermsBSTNode* root;
	int size;//number of BST node

public:
	TermsBST();
	~TermsBST();

	void setRoot(TermsBSTNode* node);//set root
	TermsBSTNode* getRoot();//get root
	int getSize();//get size

	// insert
	void insert(string name, string date1, string date2, int age);
	void search(string name);

	// delete
	void deleteNode(TermsBSTNode* curNode, TermsBSTNode* parent);
	void POST(TermsBSTNode* curNode, string date, TermsBSTNode* parent);

	//deallocate
	void deallocate(TermsBSTNode* curNode);
};