#include "TermsBST.h"

TermsBST::TermsBST() : root(nullptr)//constructor
{
	size = 0;
}
TermsBST::~TermsBST()//destructor
{
	size = 0;
	root = NULL;
}

void TermsBST::setRoot(TermsBSTNode* node) {//set root
	root = node;
}

TermsBSTNode* TermsBST::getRoot()//return root
{
	return root;
}

int TermsBST::getSize() {//return size
	return size;
}

// insert
void TermsBST::insert(string name, string date1, string date2, int age) {
	size++;
	TermsBSTNode* curNode = root;
	while (1) {
		if (root == NULL) {//first insert
			TermsBSTNode* node = new TermsBSTNode;
			node->setValue(name, date1, date2, age);
			root = node;
			break;
		}
		else {
			if (curNode->getD2() > date2) {//compare deadline date
				if (curNode->getLeft() == NULL) {//found place to insert
					TermsBSTNode* newNode = new TermsBSTNode;
					newNode->setValue(name, date1, date2, age);
					curNode->setLeft(newNode);
					break;
				}
				else//move
					curNode = curNode->getLeft();
			}
			else if (curNode->getD2() <= date2) {//compare deadline date
				if (curNode->getRight() == NULL) {//found place to insert
					TermsBSTNode* newNode = new TermsBSTNode;
					newNode->setValue(name, date1, date2, age);
					curNode->setRight(newNode);
					break;
				}
				else//move
					curNode = curNode->getRight();
			}
		}
	}
}

void TermsBST::search(string name) {//search name in TermsBST and link to delete
	TermsBSTNode* curNode = root;
	TermsBSTNode* parent = NULL;
	while (curNode != NULL) {
		if (curNode->getName() == name) {
			//delete
			deleteNode(curNode, parent);
			break;
		}
		else if (curNode->getName() > name) {//move left
			parent = curNode;
			curNode = curNode->getLeft();
		}
		else if (curNode->getName() < name) {//move right
			parent = curNode;
			curNode = curNode->getRight();
		}
	}
}

void TermsBST::deleteNode(TermsBSTNode* curNode, TermsBSTNode* parent) {
	size--;
	//subtree degree 0 
	if (curNode->getLeft() == NULL && curNode->getRight() == NULL) {
		if (curNode == root) {//delete root
			delete root;
			root = NULL;
			return;
		}
		else {
			if (parent->getLeft() == curNode) {
				delete curNode;
				curNode = NULL;
				parent->setLeft(NULL);
				return;
			}
			else if (parent->getRight() == curNode) {
				delete curNode;
				curNode = NULL;
				parent->setRight(NULL);
				return;
			}
		}
	}

	//subtree degree 1
	else if (curNode->getLeft() == NULL || curNode->getRight() == NULL) {
		if (curNode == root) {//delete root
			if (root->getLeft() != NULL) {
				TermsBSTNode* temp = root->getLeft();
				delete root;
				root = temp;
				return;
			}
			else {
				TermsBSTNode* temp = root->getRight();
				delete root;
				root = temp;
				return;
			}
		}
		else {
			if (parent->getLeft() == curNode) {
				if (curNode->getLeft() != NULL) {
					parent->setLeft(curNode->getLeft());
					delete curNode;
					curNode = NULL;
					return;
				}
				else {
					parent->setLeft(curNode->getRight());
					delete curNode;
					curNode = NULL;
					return;
				}
			}
			else {//parent->getRight()==curNode
				if (curNode->getLeft() != NULL) {
					parent->setRight(curNode->getLeft());
					delete curNode;
					curNode = NULL;
					return;
				}
				else {
					parent->setRight(curNode->getRight());
					delete curNode;
					curNode = NULL;
					return;
				}
			}
		}
	}

	//subtree degree 2
	else if (curNode->getLeft() != NULL && curNode->getRight() != NULL) {
		TermsBSTNode* rsmall = curNode->getRight();
		TermsBSTNode* rsmallp = curNode;

		if (rsmall->getLeft() == NULL) {
			if (curNode == root) {//delete root
				rsmall->setLeft(root->getLeft());
				root = rsmall;
				delete curNode;
				curNode = NULL;
				return;
			}
			else {
				rsmall->setLeft(curNode->getLeft());
				if (parent->getLeft() == curNode)
					parent->setLeft(rsmall);
				else
					parent->setRight(rsmall);
				delete curNode;
				curNode = NULL;
				return;
			}
		}
		else {//rsmall->getLeft()!=NULL
			while (rsmall->getLeft() != NULL) {
				rsmallp = rsmall;
				rsmall = rsmall->getLeft();
			}

			if (curNode == root) {
				if (rsmall->getRight() == NULL) {
					rsmallp->setLeft(NULL);
				}
				else {
					rsmallp->setLeft(rsmall->getRight());
				}
				rsmall->setLeft(curNode->getLeft());
				rsmall->setRight(curNode->getRight());
				delete curNode;
				curNode = NULL;
				root = rsmall;
				return;
			}
			else {
				if (rsmall->getRight() == NULL) {
					rsmallp->setLeft(NULL);
				}
				else {
					rsmallp->setLeft(rsmall->getRight());
				}
				rsmall->setLeft(curNode->getLeft());
				rsmall->setRight(curNode->getRight());
				parent->setRight(rsmall);
				delete curNode;
				curNode = NULL;
				return;
			}
		}
	}
}

//postorder delete by date
void TermsBST::POST(TermsBSTNode* curNode, string date, TermsBSTNode* parent) {
	if (curNode == NULL)
		return;
	POST(curNode->getLeft(), date, curNode);
	POST(curNode->getRight(), date, curNode);

	if (curNode->getD2() < date)
		deleteNode(curNode, parent);
}

//deallocate
void TermsBST::deallocate(TermsBSTNode* curNode) {
	if (curNode == nullptr)
		return;
	deallocate(curNode->getLeft());
	deallocate(curNode->getRight());
	TermsBSTNode* delNode = curNode;
	delete delNode;
}