#pragma once
#include "TermsListNode.h"

class TermsLIST
{
private:
	TermsListNode* head;
	TermsListNode* tail;
	int arr[4];

public:
	TermsLIST();
	~TermsLIST();

	TermsListNode* getHead();//return head



	// insert
	void insert(char term, string name, string date1, string date2, int age);
	// delete
	void deleteNode(char term);
	//deallocate
	void deallocate(TermsListNode* curNode);
};
