#include "MemberQueue.h"

MemberQueue::MemberQueue()
{
	this->front1 = NULL;//initialize
	this->rear = NULL;
	this->size = 0;
}
MemberQueue::~MemberQueue()
{
	this->front1 = NULL;//initialize
	this->rear = NULL;
	this->size = 0;
}

bool MemberQueue::empty()//check queue empty
{
	if (size == 0)
		return true;
	else
		return false;
}
bool MemberQueue::full()//check queue full
{
	if (size == 100)
		return true;
	else
		return false;
}
bool MemberQueue::push(string name, int age, string date, char term)//queue push
{
	if (full() == true)//queue is full
		return false;
	
	MemberQueueNode* newNode = new MemberQueueNode;
	newNode->setValue(name, age, date, term);

	if (empty() == true) {//first push
		front1 = rear = newNode;
		size++;
	}
	else {//connect with rear
		rear->setNext(newNode);
		newNode->setPrev(rear);
		rear = newNode;
		size++;
	}
	return true;
}
MemberQueueNode* MemberQueue::pop()//queue pop
{
	MemberQueueNode* popNode = front1;
	if (size == 1) {//last pop
		rear = front1 = NULL;
	}
	else {//redefine front
		front1 = front1->getNext();
	}
	size--;
	popNode->setNext(NULL);//delete
	popNode->setPrev(NULL);
	return popNode;
}
MemberQueueNode* MemberQueue::front()//return front
{
	return front1;
}

void MemberQueue::deallocate() {//deallocate
	while (empty() == false) {
		pop();
	}
}