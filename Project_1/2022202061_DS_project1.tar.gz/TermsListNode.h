#pragma once
#include <iostream>
#include "NameBST.h"
#include "TermsBST.h"
using namespace std;

class TermsListNode
{
private:
	int num;
	char term;
	TermsListNode* next;
	TermsBST* Term_BST;

public:
	TermsListNode() {//constructor
		num = 0;
		next = NULL;
		Term_BST = NULL;
	}
	~TermsListNode() {//destructor
		num = 0;
		next = NULL;
		Term_BST = NULL;
	}
	//set value
	void setValue(int num, char term) {
		this->num = num;
		this->term = term;
	}

	//ge tvalue
	int getNum() { return num; }
	char getTerm() { return term; }
	void increaseNum() { num++; }
	
	//set and get point to next node
	void setNext(TermsListNode* next) { this->next = next; }
	TermsListNode* getNext() { return next; }

	//set and get TermBST
	void setBST(TermsBST* BST) { Term_BST = BST; }
	TermsBST* getTermBST() { return Term_BST; }
};