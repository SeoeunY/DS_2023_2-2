#pragma once
#include "MemberQueue.h"
#include "TermsList.h"
#include "TermsBST.h"
#include "NameBST.h"
#include <fstream>
using namespace std;

class Manager
{
private:
	ifstream	fcmd;
	ofstream	flog;
	bool Load;//determine load call status
	MemberQueue q;
	TermsLIST T_list;//TermsList
	NameBST Name_BST;//NameBST

public:
	Manager();
	~Manager();

	void run(const char* command);

	void PrintSuccess(const char* cmd);
	void PrintErrorCode(int num);

	// LOAD
	bool LOAD();
	// ADD
	bool ADD(string name, string date, int age, char term);
	// QPOP
	bool QPOP();
	// SEARCH
	bool SEARCH(string name);
	// PRINT
	bool PRINT(string name);
	void PrintName(NameBSTNode* curNode);
	void PrintTerm(TermsBSTNode* curNode);
	// DELETE
	bool DELETE(string comm, string name);
};
